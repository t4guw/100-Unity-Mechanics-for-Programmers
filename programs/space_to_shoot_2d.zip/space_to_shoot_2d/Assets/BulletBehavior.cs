﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletBehavior : MonoBehaviour
{
    void Update()
    {
        Destroy(gameObject, 1);
    }
}
